//! Durable file/SQLite write intents. Database commits the intent before touching a file.
//! Reopening the library completes already-authorized intents before exposing the core.
use crate::config::scoped_path;
use crate::document::{Document, hash};
use crate::store::WriterLock;
use crate::{Error, IndexReport, Library, Result};
use rusqlite::params;
use std::fs::{self, File, OpenOptions};
use std::io::Write;
use std::path::Path;
use uuid::Uuid;

struct Intent {
    id: String,
    kind: String,
    relative: String,
    operation: String,
    expected: Option<String>,
    content: Option<Vec<u8>>,
    destination: Option<String>,
}

/// Revision on which an accepted derived write depends. Checked under the writer lock.
pub struct SourceGuard<'a> {
    pub source_id: &'a str,
    pub revision: u64,
    pub content_hash: &'a str,
}

impl Library {
    /// Retain an opaque original beside parsed text. The durable write-intent
    /// history contains its exact versions; originals never enter the text index.
    pub fn write_raw_asset(
        &mut self,
        relative: &str,
        bytes: Vec<u8>,
        expected: Option<&str>,
    ) -> Result<serde_json::Value> {
        if !relative.ends_with(".original") || bytes.len() > 32 * 1024 * 1024 {
            return Err(Error::Invalid(
                "opaque originals require .original and at most32 MiB".into(),
            ));
        }
        let path = scoped_path(&self.config.raw, relative)?;
        let _writer = WriterLock::acquire(&self.config)?;
        self.recover_locked()?;
        let content_hash = hash(&bytes);
        if fs::read(&path).ok().as_deref() == Some(bytes.as_slice()) {
            return Ok(
                serde_json::json!({"path":relative,"content_hash":content_hash,"unchanged":true}),
            );
        }
        check_expected(&path, expected)?;
        let intent = Intent {
            id: Uuid::new_v4().to_string(),
            kind: "raw".into(),
            relative: relative.into(),
            operation: "write_asset".into(),
            expected: expected.map(str::to_owned),
            content: Some(bytes),
            destination: None,
        };
        self.record_intent(&intent)?;
        self.recover_locked()?;
        Ok(
            serde_json::json!({"path":relative,"content_hash":content_hash,"unchanged":false,"intent_id":intent.id}),
        )
    }

    /// Create or compare-and-swap a file. None means it must not already exist.
    /// The bytes passed here are the accepted source; parsing never rewrites them.
    pub fn write_source(
        &mut self,
        kind: &str,
        relative: &str,
        bytes: Vec<u8>,
        expected: Option<&str>,
    ) -> Result<IndexReport> {
        self.write_source_checked(kind, relative, bytes, expected, None)
    }

    /// Apply reviewed bytes only while their input revision is still current on disk.
    /// Replaying the exact accepted result is idempotent, including receipt recovery.
    pub fn write_source_guarded(
        &mut self,
        kind: &str,
        relative: &str,
        bytes: Vec<u8>,
        expected: Option<&str>,
        guard: &SourceGuard<'_>,
    ) -> Result<IndexReport> {
        self.write_source_guarded_many(kind, relative, bytes, expected, std::slice::from_ref(guard))
    }

    /// As above, checking every current source used by an accepted derived write.
    pub fn write_source_guarded_many(
        &mut self,
        kind: &str,
        relative: &str,
        bytes: Vec<u8>,
        expected: Option<&str>,
        guards: &[SourceGuard<'_>],
    ) -> Result<IndexReport> {
        self.write_source_checked(kind, relative, bytes, expected, Some(guards))
    }

    fn write_source_checked(
        &mut self,
        kind: &str,
        relative: &str,
        bytes: Vec<u8>,
        expected: Option<&str>,
        guards: Option<&[SourceGuard<'_>]>,
    ) -> Result<IndexReport> {
        Document::parse(bytes.clone())?;
        let _lock = WriterLock::acquire(&self.config)?;
        self.recover_locked()?;
        for guard in guards.into_iter().flatten() {
            let source = self.get(guard.source_id, None, true)?;
            if source.deleted
                || source.revision != guard.revision
                || source.content_hash != guard.content_hash
            {
                return Err(Error::Conflict(
                    "input source changed after draft creation".into(),
                ));
            }
            let source_path = scoped_path(self.config.root_for(&source.kind)?, &source.rel_path)?;
            check_expected(&source_path, Some(guard.content_hash))?;
        }
        let path = scoped_path(self.config.root_for(kind)?, relative)?;
        if guards.is_some() && fs::read(&path).ok().as_deref() == Some(bytes.as_slice()) {
            return self.sync_locked();
        }
        check_expected(&path, expected)?;
        let intent = Intent {
            id: Uuid::new_v4().to_string(),
            kind: kind.into(),
            relative: relative.into(),
            operation: "write".into(),
            expected: expected.map(str::to_owned),
            content: Some(bytes),
            destination: None,
        };
        self.record_intent(&intent)?;
        self.recover_locked()
    }

    pub fn delete_source(&mut self, source_id: &str, expected_hash: &str) -> Result<IndexReport> {
        let _lock = WriterLock::acquire(&self.config)?;
        self.recover_locked()?;
        let source = self.get(source_id, None, true)?;
        if source.deleted {
            return Err(Error::Conflict("source already deleted".into()));
        }
        if source.content_hash != expected_hash {
            return Err(Error::Conflict("source revision changed".into()));
        }
        let path = scoped_path(self.config.root_for(&source.kind)?, &source.rel_path)?;
        check_expected(&path, Some(expected_hash))?;
        let intent = Intent {
            id: Uuid::new_v4().to_string(),
            kind: source.kind,
            relative: source.rel_path,
            operation: "delete".into(),
            expected: Some(expected_hash.into()),
            content: None,
            destination: None,
        };
        self.record_intent(&intent)?;
        self.recover_locked()
    }

    pub fn rename_source(
        &mut self,
        source_id: &str,
        destination: &str,
        expected_hash: &str,
    ) -> Result<IndexReport> {
        let _lock = WriterLock::acquire(&self.config)?;
        self.recover_locked()?;
        let source = self.get(source_id, None, true)?;
        if source.deleted || source.content_hash != expected_hash {
            return Err(Error::Conflict("source revision changed".into()));
        }
        let root = self.config.root_for(&source.kind)?;
        let path = scoped_path(root, &source.rel_path)?;
        let dest = scoped_path(root, destination)?;
        check_expected(&path, Some(expected_hash))?;
        check_expected(&dest, None)?;
        let intent = Intent {
            id: Uuid::new_v4().to_string(),
            kind: source.kind,
            relative: source.rel_path,
            operation: "rename".into(),
            expected: Some(expected_hash.into()),
            content: Some(source.content.into_bytes()),
            destination: Some(destination.into()),
        };
        self.record_intent(&intent)?;
        self.recover_locked()
    }

    fn record_intent(&self, intent: &Intent) -> Result<()> {
        self.db.execute("INSERT INTO write_intents(id,library_id,kind,relative_path,operation,expected_hash,content,destination) VALUES (?1,?2,?3,?4,?5,?6,?7,?8)",params![intent.id,self.config.library_id,intent.kind,intent.relative,intent.operation,intent.expected,intent.content,intent.destination])?;
        Ok(())
    }

    pub(crate) fn recover_locked(&mut self) -> Result<IndexReport> {
        let intents = {
            let mut stmt=self.db.prepare("SELECT id,kind,relative_path,operation,expected_hash,content,destination FROM write_intents WHERE library_id=?1 AND status='pending' ORDER BY created_at,id")?;
            stmt.query_map([&self.config.library_id], |r| {
                Ok(Intent {
                    id: r.get(0)?,
                    kind: r.get(1)?,
                    relative: r.get(2)?,
                    operation: r.get(3)?,
                    expected: r.get(4)?,
                    content: r.get(5)?,
                    destination: r.get(6)?,
                })
            })?
            .collect::<std::result::Result<Vec<_>, _>>()?
        };
        if intents.is_empty() {
            return Ok(IndexReport::default());
        }
        for intent in &intents {
            let root = self.config.root_for(&intent.kind)?;
            let path = scoped_path(root, &intent.relative)?;
            match intent.operation.as_str() {
                "write" | "write_asset" => {
                    let bytes = intent
                        .content
                        .as_ref()
                        .ok_or_else(|| Error::Conflict("write intent missing content".into()))?;
                    install(&path, bytes, intent.expected.as_deref(), &intent.id)?;
                }
                "delete" => remove(&path, intent.expected.as_deref())?,
                "rename" => {
                    let dest = scoped_path(
                        root,
                        intent.destination.as_deref().ok_or_else(|| {
                            Error::Conflict("rename intent missing destination".into())
                        })?,
                    )?;
                    let bytes = intent
                        .content
                        .as_ref()
                        .ok_or_else(|| Error::Conflict("rename intent missing content".into()))?;
                    // Destination may already exist with exact accepted bytes after a crash.
                    install(&dest, bytes, None, &intent.id)?;
                    remove(&path, intent.expected.as_deref())?;
                }
                _ => return Err(Error::Conflict("unknown pending write operation".into())),
            }
        }
        let report = if intents
            .iter()
            .any(|intent| intent.operation != "write_asset")
        {
            self.sync_locked()?
        } else {
            IndexReport::default()
        };
        let tx = self.db.transaction()?;
        for intent in &intents {
            tx.execute(
                "UPDATE write_intents SET status='applied' WHERE id=?1 AND library_id=?2",
                params![intent.id, self.config.library_id],
            )?;
        }
        tx.commit()?;
        Ok(report)
    }
}

fn check_expected(path: &Path, expected: Option<&str>) -> Result<()> {
    match fs::read(path) {
        Ok(bytes) if expected == Some(hash(&bytes).as_str()) => Ok(()),
        Err(e) if e.kind() == std::io::ErrorKind::NotFound && expected.is_none() => Ok(()),
        Err(e) if e.kind() != std::io::ErrorKind::NotFound => Err(e.into()),
        _ => Err(Error::Conflict(
            "file changed outside the accepted revision; no overwrite performed".into(),
        )),
    }
}

fn install(path: &Path, bytes: &[u8], expected: Option<&str>, intent_id: &str) -> Result<()> {
    if let Ok(current) = fs::read(path)
        && current == bytes
    {
        return Ok(());
    }
    check_expected(path, expected)?;
    let parent = path
        .parent()
        .ok_or_else(|| Error::Invalid("source path has no parent".into()))?;
    fs::create_dir_all(parent)?;
    let temp = parent.join(format!(".llmbase-{intent_id}-{}.stage", Uuid::new_v4()));
    let mut file = OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(&temp)?;
    file.write_all(bytes)?;
    file.sync_all()?;
    fs::rename(&temp, path)?;
    File::open(parent)?.sync_all()?;
    Ok(())
}

fn remove(path: &Path, expected: Option<&str>) -> Result<()> {
    match fs::symlink_metadata(path) {
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => return Ok(()),
        Err(e) => return Err(e.into()),
        _ => {}
    }
    check_expected(path, expected)?;
    fs::remove_file(path)?;
    if let Some(parent) = path.parent() {
        File::open(parent)?.sync_all()?;
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::LibraryConfig;
    use tempfile::TempDir;

    #[test]
    fn recovery_handles_before_file_and_after_file_crash_windows() {
        for after_file in [false, true] {
            let dir = TempDir::new().unwrap();
            let config = LibraryConfig::load(dir.path(), "recover").unwrap();
            let library = Library::open(config.clone()).unwrap();
            let bytes = b"immutable original source".to_vec();
            let intent = Intent {
                id: "test-intent".into(),
                kind: "raw".into(),
                relative: "a.md".into(),
                operation: "write".into(),
                expected: None,
                content: Some(bytes.clone()),
                destination: None,
            };
            library.record_intent(&intent).unwrap();
            if after_file {
                install(&config.raw.join("a.md"), &bytes, None, &intent.id).unwrap();
            }
            drop(library);
            let mut reopened = Library::open(config).unwrap();
            assert_eq!(
                reopened.get("a", None, false).unwrap().content,
                "immutable original source"
            );
            assert_eq!(reopened.sync().unwrap().unchanged, 1);
            let status: String = reopened
                .db
                .query_row("SELECT status FROM write_intents", [], |r| r.get(0))
                .unwrap();
            assert_eq!(status, "applied");
        }
    }

    #[test]
    fn accepted_writes_require_compare_and_swap_and_preserve_old_citations() {
        let dir = TempDir::new().unwrap();
        let mut library = Library::open(LibraryConfig::load(dir.path(), "write").unwrap()).unwrap();
        library
            .write_source("raw", "a.md", b"old accepted content".to_vec(), None)
            .unwrap();
        let original = library.get("a", None, false).unwrap();
        assert!(
            library
                .write_source("raw", "a.md", b"new content".to_vec(), None)
                .is_err()
        );
        library
            .write_source(
                "raw",
                "a.md",
                b"new content".to_vec(),
                Some(&original.content_hash),
            )
            .unwrap();
        let current = library.get("a", None, false).unwrap();
        assert_eq!(current.revision, 2);
        assert!(
            library
                .delete_source(&current.source_id, &original.content_hash)
                .is_err()
        );
        library
            .rename_source(&current.source_id, "renamed.md", &current.content_hash)
            .unwrap();
        library
            .delete_source(&current.source_id, &current.content_hash)
            .unwrap();
        assert!(
            library
                .get(&current.source_id, None, false)
                .unwrap()
                .deleted
        );
        assert_eq!(
            library
                .get(&current.source_id, Some(1), false)
                .unwrap()
                .content,
            "old accepted content"
        );
    }

    #[test]
    fn recovery_does_not_overwrite_an_unrelated_external_edit() {
        let dir = TempDir::new().unwrap();
        let config = LibraryConfig::load(dir.path(), "conflict").unwrap();
        let library = Library::open(config.clone()).unwrap();
        let intent = Intent {
            id: "conflict".into(),
            kind: "raw".into(),
            relative: "a.md".into(),
            operation: "write".into(),
            expected: None,
            content: Some(b"accepted".to_vec()),
            destination: None,
        };
        library.record_intent(&intent).unwrap();
        fs::create_dir_all(&config.raw).unwrap();
        fs::write(config.raw.join("a.md"), "external edit").unwrap();
        drop(library);
        assert!(matches!(
            Library::open(config.clone()),
            Err(Error::Conflict(_))
        ));
        assert_eq!(
            fs::read_to_string(config.raw.join("a.md")).unwrap(),
            "external edit"
        );
    }
}
