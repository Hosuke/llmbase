#!/usr/bin/env python3
"""Finite offline native lifecycle proof; Python is a test harness, never a core dependency.

On Linux --chroot copies only the release ELF and its shared libraries into an
empty runtime root. The HTTP fixture and this controller stay outside that root.
No real provider, credential, production document, or semantic-quality claim.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


REQUESTS = []


class Provider(BaseHTTPRequestHandler):
    def log_message(self, *_args):
        pass

    def do_POST(self):
        request = json.loads(self.rfile.read(int(self.headers["content-length"])))
        REQUESTS.append({"path": self.path, "stream": request.get("stream", False)})
        if self.path.endswith("/embeddings"):
            data = []
            for index, value in enumerate(request["input"]):
                vector = [1.0, 0.0, 0.0] if "orchard" in value.lower() else [0.0, 1.0, 0.0]
                data.append({"index": index, "embedding": vector})
            body = {"model": "fixture-embedding", "data": data, "usage": {"prompt_tokens": 8, "total_tokens": 8}}
        elif request.get("stream"):
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Connection", "close")
            self.end_headers()
            for piece in ["Orchards ", "grow fruit [E1]."]:
                frame = {"model": "fixture-generation", "choices": [{"index": 0, "delta": {"content": piece}, "finish_reason": None}]}
                self.wfile.write(f"data: {json.dumps(frame)}\n\n".encode())
                self.wfile.flush()
            final = {"model": "fixture-generation", "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}], "usage": {"prompt_tokens": 10, "completion_tokens": 8, "total_tokens": 18}}
            self.wfile.write(f"data: {json.dumps(final)}\n\ndata: [DONE]\n\n".encode())
            self.wfile.flush()
            return
        else:
            promote = "Evaluate whether" in request["messages"][0]["content"]
            article = {"slug": "orchard-answer" if promote else "orchard-knowledge", "title": "Orchard answer" if promote else "Orchard knowledge", "summary": "Cultivation from source evidence", "tags": ["botany"], "aliases": [], "content": "Orchards grow fruit. 學而時習之。"}
            content = {"promote": True, "reason": "Reusable fixture knowledge", "article": article} if promote else {"articles": [article]}
            body = {"model": "fixture-generation", "choices": [{"message": {"content": json.dumps(content, ensure_ascii=False)}, "finish_reason": "stop"}], "usage": {"prompt_tokens": 10, "completion_tokens": 8, "total_tokens": 18}}
        encoded = json.dumps(body).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--run-root", type=Path, required=True)
    parser.add_argument("--chroot", action="store_true")
    args = parser.parse_args()
    binary = args.binary.resolve(strict=True)
    run = args.run_root.absolute()
    if run.exists():
        raise SystemExit("run-root must be a new isolated directory")
    run.mkdir(parents=True)
    runtime = run / "runtime"
    library = runtime / "library"
    library.mkdir(parents=True)
    prefix = [str(binary)]
    base = str(library)
    if args.chroot:
        if os.geteuid() != 0 or not shutil.which("chroot"):
            raise SystemExit("--chroot requires the isolated Linux root runner")
        (runtime / "bin").mkdir()
        shutil.copy2(binary, runtime / "bin/llmbase")
        dependencies = subprocess.check_output(["ldd", str(binary)], text=True)
        (run / "ldd.txt").write_text(dependencies)
        for name in sorted(set(re.findall(r"(/[^\s()]+)", dependencies))):
            source = Path(name)
            destination = runtime / source.relative_to("/")
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source.resolve(), destination)
        prefix = [shutil.which("chroot"), str(runtime), "/bin/llmbase"]
        base = "/library"
        assert not any(path.name.startswith(("python", "pypy")) for path in runtime.rglob("*"))
    server = ThreadingHTTPServer(("127.0.0.1", 0), Provider)
    server.daemon_threads = True
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    endpoint = f"http://127.0.0.1:{server.server_port}/v1"
    env = {"PATH": "/no-interpreters", "LLMBASE_BASE_URL": endpoint,
           "LLMBASE_MODEL": "fixture-generation", "LLMBASE_EMBEDDING_BASE_URL": endpoint,
           "LLMBASE_EMBEDDING_MODEL": "fixture-embedding", "LLMBASE_PRIMARY_RETRIES": "1"}
    steps = []

    def invoke(*command, stream=False):
        started = time.monotonic()
        result = subprocess.run(prefix + ["--base-dir", base, "--library-id", "standalone", "--json", *command],
                                env=env, capture_output=True, text=True, timeout=45)
        steps.append({"command": list(command[:2]), "exit": result.returncode,
                      "wall_ms": round((time.monotonic() - started) * 1000, 3)})
        if result.returncode:
            raise RuntimeError(f"{command[:2]}: {result.stderr or result.stdout}")
        return [json.loads(line) for line in result.stdout.splitlines()] if stream else json.loads(result.stdout)

    def op(name, **payload):
        return invoke("op", name, "--args", json.dumps(payload, ensure_ascii=False))

    try:
        original = "---\ntitle: Orchard source\nunknown: {retained: 𠮷}\nsource_url: https://example.invalid/orchard\n---\nAn orchard grows fruit. 學而時習之。\n"
        op("source_write", kind="raw", path="orchard.md", content=original)
        report = invoke("compile", "source", "orchard")
        assert report["status"] == "succeeded"
        assert not (library / "wiki/concepts/orchard-knowledge.md").exists()
        draft = invoke("compile", "draft", report["draft_ids"][0])
        invoke("compile", "apply", draft["id"])
        assert (library / "raw/orchard.md").read_bytes() == original.encode()
        assert invoke("index")["passages_written"] == 0
        queued = op("job_enqueue", operation="index", args={})
        finished = op("job_run_one", worker_id="standalone-fixture")
        assert finished["id"] == queued["id"] and finished["status"] == "succeeded"
        assert op("job_get", job_id=queued["id"])["attempts"] == 1
        lexical = op("search", query="orchard", kind="raw")
        evidence = lexical["results"][0]["evidence"]
        assert not op("evidence", evidence=evidence)["stale"]
        vectors = op("vector_build", dimension=3, revision="fixture-v1")
        assert vectors["embedded"] > 0
        assert op("vector_build", dimension=3, revision="fixture-v1")["reused_active"]
        assert op("hybrid_search", query="orchard", kind="raw")["mode"] == "hybrid"
        events = invoke("ask", "What grows in an orchard?", "--top-k", "1", "--stream", stream=True)
        assert any(event.get("type") == "delta" for event in events)
        assert events[-1]["type"] == "done"
        answer = invoke("ask", "What grows in an orchard?", "--top-k", "1")
        assert answer["used_evidence"]
        saved = op("answer_save", request={"library_id": "standalone", "question": "What grows in an orchard?", "title": "Orchard answer", "visibility": "public"}, response=answer)
        promotion = op("answer_promote", answer_id=saved["id"])
        assert promotion["promote"] and promotion["draft_id"]
        invoke("compile", "apply", promotion["draft_id"])
        exported = op("export_article", slug="orchard-knowledge")
        assert exported["slug"] == "orchard-knowledge"
        projection = op("rebuild_metadata")
        assert projection["article_count"] == 2
        op("source_write", kind="raw", path="orchard.md", content=original + "Accepted new source revision.\n", expected_hash=evidence["content_hash"])
        assert op("evidence", evidence=evidence)["stale"]
        current = op("get", source_id=evidence["source_id"])
        op("source_delete", source_id=current["source_id"], expected_hash=current["content_hash"])
        assert not op("search", query="orchard", kind="raw")["results"]
        assert op("evidence", evidence=evidence)["deleted"]
        snapshot = "/snapshot" if args.chroot else str(runtime / "snapshot")
        restored = "/restored" if args.chroot else str(runtime / "restored")
        invoke("migration", "backup", snapshot)
        invoke("migration", "verify", snapshot)
        invoke("migration", "restore", snapshot, restored)
        invoke("migration", "verify", restored)
        invoke("migration", "rollback", snapshot)
        receipt = {"passed": True, "binary_sha256": hashlib.sha256(binary.read_bytes()).hexdigest(),
                   "isolated_runtime_without_python": args.chroot, "steps": steps,
                   "provider_fixture_requests": REQUESTS, "semantic_quality": "not evaluated",
                   "provider": "offline deterministic HTTP fixture; no credentials",
                   "runtime_files": sorted(str(path.relative_to(runtime)) for path in runtime.rglob("*") if path.is_file())}
        (run / "receipt.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2))
        print(json.dumps({"passed": True, "steps": len(steps), "receipt": str(run / "receipt.json")}, indent=2))
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=2)


if __name__ == "__main__":
    main()
