use fs2::FileExt;
use llmbase_core::{LibraryConfig, compat_io, store::WriterSession};
use std::fs;

#[test]
fn standalone_atomic_write_is_durable_exact_and_fenced() {
    let temp = tempfile::tempdir().unwrap();
    let path = temp.path().join("new/value.json");
    let receipt = compat_io::atomic_write(&path, b"{\"v\":NaN}", None).unwrap();
    assert_eq!(fs::read(&path).unwrap(), b"{\"v\":NaN}");
    assert_eq!(receipt["coordination"], "standalone_file_lock");
    assert_eq!(receipt["journal"], false);
    let lock = fs::OpenOptions::new()
        .read(true)
        .write(true)
        .open(path.parent().unwrap().join(".value.json.llmbase.lock"))
        .unwrap();
    lock.try_lock_exclusive().unwrap();
    assert!(matches!(
        compat_io::atomic_write(&path, b"bad", None),
        Err(llmbase_core::Error::Busy)
    ));
    assert_eq!(fs::read(&path).unwrap(), b"{\"v\":NaN}");
    FileExt::unlock(&lock).unwrap();
    compat_io::atomic_write(&path, b"replacement", None).unwrap();
    assert_eq!(fs::read(&path).unwrap(), b"replacement");
    assert!(
        !fs::read_dir(path.parent().unwrap()).unwrap().any(|p| p
            .unwrap()
            .path()
            .extension()
            .is_some_and(|e| e == "stage"))
    );
}

#[test]
fn explicit_library_atomic_write_reuses_shared_writer_and_rejects_escape() {
    let temp = tempfile::tempdir().unwrap();
    let config = LibraryConfig::load(temp.path(), "fixture").unwrap();
    let path = config.meta.join("custom.json");
    let session = WriterSession::acquire(&config).unwrap();
    let receipt = compat_io::atomic_write(&path, b"{}", Some(&config)).unwrap();
    assert_eq!(receipt["coordination"], "library_writer_and_file_lock");
    assert!(!config.database().exists());
    assert!(matches!(
        compat_io::atomic_write(&temp.path().join("outside.json"), b"{}", Some(&config)),
        Err(llmbase_core::Error::Scope)
    ));
    drop(session);
    let lock = fs::OpenOptions::new()
        .read(true)
        .write(true)
        .open(config.meta.join("llmbase.writer.lock"))
        .unwrap();
    lock.try_lock_exclusive().unwrap();
    assert!(matches!(
        compat_io::atomic_write(&path, b"bad", Some(&config)),
        Err(llmbase_core::Error::Busy)
    ));
    assert_eq!(fs::read(path).unwrap(), b"{}");
}
