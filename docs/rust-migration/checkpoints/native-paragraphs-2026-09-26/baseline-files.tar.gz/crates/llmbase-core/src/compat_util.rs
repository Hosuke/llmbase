//! Pure compatibility primitives. Offsets here are Unicode scalar indices,
//! matching Python strings; indexed evidence keeps its separate UTF-8 byte unit.
use crate::{Error, Result, compat_kb};
use serde_json::{Value, json};
use sha1::{Digest, Sha1};

fn field<'a>(args: &'a Value, key: &str) -> Result<&'a str> {
    args.get(key)
        .and_then(Value::as_str)
        .ok_or_else(|| Error::Invalid(format!("{key} must be a string")))
}
fn whitespace(c: char) -> bool {
    c.is_whitespace() || matches!(c, '\u{1c}'..='\u{1f}')
}

fn headings(body: &str) -> Vec<Value> {
    fn flatten(nodes: &Value, output: &mut Vec<Value>) {
        for node in nodes.as_array().unwrap() {
            output.push(json!([node["level"], node["start"], node["title"]]));
            flatten(&node["children"], output);
        }
    }
    let mut result = Vec::new();
    flatten(&compat_kb::parse_sections(body), &mut result);
    result
}

fn find_path(nodes: &Value, anchor: &str, path: &mut Vec<usize>) -> Result<bool> {
    let nodes = nodes
        .as_array()
        .ok_or_else(|| Error::Invalid("sections must be an array".into()))?;
    for (index, node) in nodes.iter().enumerate() {
        path.push(index);
        if node.get("anchor") == Some(&json!(anchor)) {
            return Ok(true);
        }
        if find_path(node.get("children").unwrap_or(&json!([])), anchor, path)? {
            return Ok(true);
        }
        path.pop();
    }
    Ok(false)
}

fn normalize_span(content: &str, level: &str) -> Result<(String, Vec<usize>)> {
    if !matches!(level, "none" | "punct" | "punct_spaces") {
        return Err(Error::Invalid(format!("unknown normalize level: {level}")));
    }
    const PUNCT: &str = "！。，、；：？「」『』（）〔〕【】《》〈〉·・—–―…!.,;:?()[]{}\"'";
    let mut text = String::new();
    let mut mapping = Vec::new();
    for (index, ch) in content.chars().enumerate() {
        if level != "none" && (PUNCT.contains(ch) || level == "punct_spaces" && whitespace(ch)) {
            continue;
        }
        text.push(ch);
        mapping.push(index);
    }
    Ok((text, mapping))
}

fn locate(args: &Value) -> Result<Value> {
    let content = field(args, "content")?;
    let head = field(args, "head")?;
    let tail = args.get("tail").and_then(Value::as_str).unwrap_or("");
    if head.is_empty() {
        return Err(Error::Invalid("head must not be empty".into()));
    }
    if content.is_empty() {
        return Ok(Value::Null);
    }
    let level = args
        .get("normalize")
        .and_then(Value::as_str)
        .unwrap_or("punct_spaces");
    let (normalized, map) = normalize_span(content, level)?;
    let (head, _) = normalize_span(head, level)?;
    if head.is_empty() {
        return Ok(Value::Null);
    }
    let Some(start) = normalized.find(&head) else {
        return Ok(Value::Null);
    };
    let start_original = map[normalized[..start].chars().count()];
    if !tail.is_empty() {
        let (tail, _) = normalize_span(tail, level)?;
        if !tail.is_empty()
            && let Some(offset) = normalized[start + head.len()..].find(&tail)
        {
            let end_byte = start + head.len() + offset + tail.len();
            let end_original = map[normalized[..end_byte].chars().count() - 1] + 1;
            return Ok(json!({"start":start_original,"end":end_original,"strategy":"exact"}));
        }
    }
    Ok(json!({"start":start_original,"end":content.chars().count(),"strategy":"head_only"}))
}

fn split(args: &Value) -> Result<Value> {
    let body = field(args, "body")?;
    let level = args
        .get("level")
        .and_then(Value::as_u64)
        .filter(|v| (1..=6).contains(v))
        .ok_or_else(|| Error::Invalid("level must be 1..6".into()))?;
    let heads = headings(body);
    let chars: Vec<char> = body.chars().collect();
    let mut result = Vec::new();
    for (index, head) in heads.iter().enumerate() {
        if head[0] != level {
            continue;
        }
        let start = head[1].as_u64().unwrap() as usize;
        let end = heads[index + 1..]
            .iter()
            .find(|h| h[0].as_u64().unwrap() <= level)
            .map(|h| h[1].as_u64().unwrap() as usize)
            .unwrap_or(chars.len());
        let newline = (start..end).find(|&i| matches!(chars[i], '\r' | '\n'));
        let (header_end, content_start) = match newline {
            Some(i) => (
                i,
                i + if chars[i] == '\r' && i + 1 < end && chars[i + 1] == '\n' {
                    2
                } else {
                    1
                },
            ),
            None => (end, end),
        };
        result.push(json!({"level":level,"title":head[2],"header_line":chars[start..header_end].iter().collect::<String>(),
            "start":start,"end":end,"content":chars[content_start..end].iter().collect::<String>().trim_matches(whitespace)}));
    }
    Ok(json!(result))
}

pub fn transform(action: &str, args: &Value) -> Result<Value> {
    if !args.is_object() {
        return Err(Error::Invalid("utility arguments must be an object".into()));
    }
    match action {
        "normalize_title" => Ok(json!(compat_kb::normalized_title(field(args, "text")?))),
        "sha1" => Ok(json!(format!(
            "{:x}",
            Sha1::digest(field(args, "text")?.as_bytes())
        ))),
        "make_anchor" => {
            let titles = args
                .get("titles")
                .and_then(Value::as_array)
                .filter(|v| !v.is_empty())
                .ok_or_else(|| {
                    Error::Invalid("ancestor_titles must contain at least the current title".into())
                })?;
            let normalized = titles
                .iter()
                .map(|t| {
                    t.as_str()
                        .map(compat_kb::normalized_title)
                        .ok_or_else(|| Error::Invalid("ancestor titles must be strings".into()))
                })
                .collect::<Result<Vec<_>>>()?;
            let max = args.get("slug_max").and_then(Value::as_u64).unwrap_or(20) as usize;
            let hash_len = args.get("hash_len").and_then(Value::as_u64).unwrap_or(6) as usize;
            let separator = args.get("separator").and_then(Value::as_str).unwrap_or("›");
            let fallback = args.get("fallback").and_then(Value::as_str).unwrap_or("_");
            let last = normalized.last().unwrap();
            let short = if last.is_empty() {
                fallback.into()
            } else {
                last.chars().take(max).collect::<String>()
            };
            let digest = format!("{:x}", Sha1::digest(normalized.join(separator).as_bytes()));
            let level = args
                .get("level")
                .ok_or_else(|| Error::Invalid("level is required".into()))?;
            Ok(json!(format!(
                "h{level}-{short}-{}",
                &digest[..hash_len.min(digest.len())]
            )))
        }
        "sections" => Ok(compat_kb::parse_sections(field(args, "body")?)),
        "headings" => Ok(json!(headings(field(args, "body")?))),
        "find_section_path" => {
            let mut path = Vec::new();
            if find_path(
                args.get("sections").unwrap_or(&json!([])),
                field(args, "anchor")?,
                &mut path,
            )? {
                Ok(json!(path))
            } else {
                Ok(Value::Null)
            }
        }
        "extract_section" => {
            let body = field(args, "body")?;
            let mut path = Vec::new();
            let mut nodes = args.get("sections").unwrap_or(&Value::Null);
            if !find_path(nodes, field(args, "anchor")?, &mut path)? {
                return Ok(Value::Null);
            }
            let mut found = &Value::Null;
            for index in path {
                found = &nodes[index];
                nodes = &found["children"];
            }
            let start = found["start"]
                .as_u64()
                .ok_or_else(|| Error::Invalid("invalid section offset".into()))?
                as usize;
            let end = found["end"]
                .as_u64()
                .ok_or_else(|| Error::Invalid("invalid section offset".into()))?
                as usize;
            Ok(json!(
                body.chars()
                    .skip(start)
                    .take(end.saturating_sub(start))
                    .collect::<String>()
            ))
        }
        "split" => split(args),
        "normalize_span" => Ok(json!(
            normalize_span(field(args, "text")?, field(args, "level")?)?.0
        )),
        "normalize_span_map" => {
            let (text, map) = normalize_span(field(args, "text")?, field(args, "level")?)?;
            Ok(json!([text, map]))
        }
        "locate_span" => locate(args),
        _ => Err(Error::Invalid("unknown utility transform".into())),
    }
}
