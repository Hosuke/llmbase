use pyo3::prelude::*;
use serde_json::{Value, json};
use std::sync::atomic::{AtomicU64, Ordering};
static CALLS: AtomicU64 = AtomicU64::new(0);

#[pyfunction]
fn utility_transform(py: Python<'_>, action: String, args_json: String) -> PyResult<String> {
    py.detach(move||{
        let args:Value=serde_json::from_str(&args_json).map_err(llmbase_core::Error::from).map_err(super::python_error)?;
        let value=llmbase_core::compat_util::transform(&action,&args).map_err(super::python_error)?;
        Ok(json!({"value":value,"trace":{"core":"rust","operation":format!("utility_{action}"),
            "adapter":"llmbase_core::compat_util::transform","offset_unit":"unicode_scalars","sequence":CALLS.fetch_add(1,Ordering::Relaxed)+1}}).to_string())
    })
}
pub fn register(module: &Bound<'_, PyModule>) -> PyResult<()> {
    module.add_function(wrap_pyfunction!(utility_transform, module)?)?;
    module.add_function(wrap_pyfunction!(atomic_write_at, module)?)?;
    Ok(())
}

#[pyfunction]
#[pyo3(signature=(path,content,base_dir=None,library_id="default",paths_json=None))]
fn atomic_write_at(
    py: Python<'_>,
    path: String,
    content: Vec<u8>,
    base_dir: Option<String>,
    library_id: &str,
    paths_json: Option<String>,
) -> PyResult<String> {
    let library_id = library_id.to_owned();
    py.detach(move || {
        let config = base_dir
            .as_ref()
            .map(|base| super::configured_library(base, &library_id, paths_json.as_deref()))
            .transpose()?;
        let value = llmbase_core::compat_io::atomic_write(
            std::path::Path::new(&path),
            &content,
            config.as_ref(),
        )
        .map_err(super::python_error)?;
        Ok(
            json!({"value":value,"trace":{"core":"rust","operation":"atomic_write",
            "adapter":"llmbase_core::compat_io::atomic_write","coordination":value["coordination"],
            "journal":value["journal"],"library_id":config.as_ref().map(|c|&c.library_id),
            "sequence":CALLS.fetch_add(1,Ordering::Relaxed)+1}})
            .to_string(),
        )
    })
}
